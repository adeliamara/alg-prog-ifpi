import {print, input} from './\io_utils.js';

function main(){
    const distance = Number(input('Entre com o numero a '));
    
    const tempo = distance * 2
    
    console.log(`${tempo} minutos`)
    
}


main()
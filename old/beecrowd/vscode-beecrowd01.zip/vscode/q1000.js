import {print, input} from './\io_utils.js';


function main(){
    print(`Hello World!`);

}

main()
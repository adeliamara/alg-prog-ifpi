import {print, input} from './\io_utils.js';


function main(){
    //entrada
    const a = Number(input('Entre com o numero a '));
    const b = Number(input('Entre com o numero b '));

    //processamento;=
    const X = a + b

    //resultado
    print(`X = ${X}`);

}

main()
import {print, input} from './\io_utils.js';

function main(){
    const A = Number(input('Entre com o numero a '));
    const B = Number(input('Entre com o numero b '));

    const PROD = A * B
    
    console.log(`PROD = ${PROD}`);
   
}

main()
import {print, input} from './\io_utils.js';


function main(){
    //entrada
    const A = Number(input('Entre com o numero a '));
    const B = Number(input('Entre com o numero b '));
    
    const SOMA = A + B
    
    console.log(`SOMA = ${SOMA}`);
   
}

main()